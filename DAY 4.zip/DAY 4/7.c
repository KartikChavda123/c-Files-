#include <stdio.h>
int main(){
    int a=50,b=10,c;
    c=a/b;
    printf("%d",c);
}