#include <stdio.h>
int main(){
    int a=9,b;
    b=a*a;
    printf("Squre is :%d",b);
}