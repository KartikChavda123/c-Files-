#include <stdio.h>
int main(){
    int a=3,b=5,c;
    c=a+b;
    printf("Adition of two numbers: %d\n",c);
}