#include <stdio.h>
int main(){
    int a=5,b=3,c=7,d=2,e;
    e=a+b*a-b;
    printf("%d",e);
}