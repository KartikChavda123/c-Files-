#include <stdio.h>
int main(){
    int a=10,b=20,c=30,d;
    d=a+b+c;
    printf("Avr is %d",d/3);
}