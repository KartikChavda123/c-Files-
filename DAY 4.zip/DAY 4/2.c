#include <stdio.h>
int main(){
    int a=4,b=6,c;
    c=a*b;
    printf("Multiplication of two numbers:%d",c);
}