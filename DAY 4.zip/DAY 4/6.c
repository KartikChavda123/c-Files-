#include <stdio.h>
int main(){
    int a=2,b;

    b=a*a*a;
    printf("%d",b);
}