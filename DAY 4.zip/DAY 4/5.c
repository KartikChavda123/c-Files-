#include <stdio.h>
int main(){
    int a=1000,b=5,c=2,d;
    d=a/(b*c);
    printf("%d",d);
}