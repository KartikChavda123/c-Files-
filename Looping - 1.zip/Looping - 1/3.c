#include <stdio.h>
int main(){
    int i=0,k;

    printf("Enter The Value :");
    scanf("%d",&k);

    while (i<=k)
    {
        printf("%d\n",i);
        i++;
    }
    
}