#include <stdio.h>
int main(){
    int p,l=11,w=18;
    p=(2*l)+(2*w);
    printf("%d",p);
}