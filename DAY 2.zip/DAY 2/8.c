#include <stdio.h>
int main(){
    int k,l=8;
    k=l*4;
    printf("Squre of %d",k);
}