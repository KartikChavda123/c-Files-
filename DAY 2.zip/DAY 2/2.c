#include <stdio.h>
int main(){
    int l=3;
    int b=l*l;
    printf("Area of tringale %d",b);
}