#include <stdio.h>
int main(){
    int a=10,b=30,c;
    c=a+b;
    printf("Sum of Two number %d",c);
}