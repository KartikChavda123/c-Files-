#include <stdio.h>
int main(){
    int a=10,b=5,c;
    c=a/b;
    printf("Divistion of two numbers %d",c);
}