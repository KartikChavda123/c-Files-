#include <stdio.h>
int main(){
    int a=10,b=25,c=63,d=55,e;
    e=a*b*c*d;
    printf("Multiplication of Four Numbers %d",e);
}