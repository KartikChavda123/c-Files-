#include <stdio.h>
int main(){
    int w=10,l=20;
    int c = l*w;
    printf("Area of tringal %d",c);
}