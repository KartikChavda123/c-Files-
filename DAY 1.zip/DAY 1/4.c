#include <stdio.h>
int main(){
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\t\t\t\t\t**\t\t\t\t\t\t\t*\n");
    printf("*\t\t\t\t*\t\t*\t\t\t\t\t*\n");
    printf("*\t\t\t*\t\t\t\t*\t\t\t*\n");
    printf("*\t\t*\t\t\t\t\t\t**\n");
    printf("*\t*\n");
    printf("*\n");
}