#include <stdio.h>
 int main(){
    printf("My name is Chavda Kartik\n");
    printf("Age 19\n");
    printf("Red And White institute");
}