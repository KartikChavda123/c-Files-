#include <stdio.h>
int main(){
    printf("---------\n");
    printf("|\t\t|\n");
    printf("R\t\t|\n");
    printf("N\t\t|\n");
    printf("W\t\t|\n");
    printf("|\t\t|\n");
    printf("---------\n");
}