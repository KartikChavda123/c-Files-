#include <stdio.h>
int main(){
    int a;
    printf("Enter the value of a=");
    scanf("%d",&a);

    printf("entre %d",a*15);
}