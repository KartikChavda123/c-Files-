#include <stdio.h>
int main(){
    int a,b,c;
    printf("Enter the value of a");
    scanf("%d",&a);

    printf("Enter the value oof b");
    scanf("%d",&b);

    c=a*b;

    printf("%d",c);

}