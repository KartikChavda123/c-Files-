#include <stdio.h>
int main(){
    int a,b,avr;
    printf("Entre the value of a");
    scanf("%d",&a);

    printf("Enter the value of b");
    scanf("%d",&b);

    avr=(a+b)/2;

    printf("avrage=%d",avr);

}